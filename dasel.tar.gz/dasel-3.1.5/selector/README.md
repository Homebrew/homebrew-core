# Selector

The selector package contains everything needed to parse a selector string into an AST, which we can then execute.
