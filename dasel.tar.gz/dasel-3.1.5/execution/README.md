# Execution

The execution package accepts a `model.Value`, parses a selector and executes the resulting AST on the value.
