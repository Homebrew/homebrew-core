# Model

The model package contains the Value struct and functionality for the application.

`model.Value` is just a wrapper around `reflect.Value` but provides some additional logic for easier use.
