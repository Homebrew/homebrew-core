
<a name="v0.3.4"></a>

## [v0.3.4](https://github.com/MuntasirSZN/getquotes/compare/v0.3.3...v0.3.4) (2025-02-03)

### Chore

- **release:** v0.3.4
  
  
<a name="v0.3.3"></a>

## [v0.3.3](https://github.com/MuntasirSZN/getquotes/compare/v0.3.2...v0.3.3) (2025-02-02)


<a name="v0.3.2"></a>

## [v0.3.2](https://github.com/MuntasirSZN/getquotes/compare/v0.3.1...v0.3.2) (2025-02-02)

### Chore

- **release:** v0.3.2
  
  ### ✨ Features

- **workflow:** some verbosity
  - **workflow:** done making granular
  
  
<a name="v0.3.1"></a>

## [v0.3.1](https://github.com/MuntasirSZN/getquotes/compare/v0.3.0...v0.3.1) (2025-02-02)

### 🐞 Bug Fixes

- **workflow:** test code first
  - **workflow:** test code first
  
  
<a name="v0.3.0"></a>

## [v0.3.0](https://github.com/MuntasirSZN/getquotes/compare/v0.2.8...v0.3.0) (2025-02-02)

### Build

- **deps:** bump serde_json from 1.0.137 to 1.0.138
  - **deps:** bump rand from 0.8.5 to 0.9.0
  - **deps:** bump clap from 4.5.26 to 4.5.27
  
  ### Chore

- **release:** v0.3.0
  
  ### 🐞 Bug Fixes

- **caching:** now cache is used perfectly
  - **rng:** depreacated funcs
  - **workflow:** test code first
  
  
<a name="v0.2.8"></a>

## [v0.2.8](https://github.com/MuntasirSZN/getquotes/compare/v0.2.7...v0.2.8) (2025-01-20)

### 🐞 Bug Fixes

- **workflow:** again
  
  
<a name="v0.2.7"></a>

## [v0.2.7](https://github.com/MuntasirSZN/getquotes/compare/v0.2.6...v0.2.7) (2025-01-20)

### Build

- **deps:** bump rusqlite from 0.32.1 to 0.33.0
  - **deps:** bump serde_json from 1.0.135 to 1.0.137
  
  ### 🐞 Bug Fixes

- **script:** handle pkgver only fix(workflow): use updpkgsums chore(release): update to 0.2.7
  
  
<a name="v0.2.6"></a>

## [v0.2.6](https://github.com/MuntasirSZN/getquotes/compare/v0.2.5...v0.2.6) (2025-01-18)

### Chore

- **release:** v0.2.6
  
  
<a name="v0.2.5"></a>

## [v0.2.5](https://github.com/MuntasirSZN/getquotes/compare/v0.2.4...v0.2.5) (2025-01-18)

### Chore

- **release:** v0.2.5
  
  ### ✨ Features

- better changelog
  - All packages are in packages dir feat: CI scripts are in ci dir feat: Experimental homebrew (working currently) fix(workflow): Comply with changes
  
  ### 🐞 Bug Fixes

- **workflow:** try
  
  
<a name="v0.2.4"></a>

## [v0.2.4](https://github.com/MuntasirSZN/getquotes/compare/v0.2.3...v0.2.4) (2025-01-18)

### Chore

- **release:** v0.2.4
  
  ### 🐞 Bug Fixes

- **git-rev:** Dont panic!(), just return empty string
  - **readme:** Add versions, and some notes
  
  
<a name="v0.2.3"></a>

## [v0.2.3](https://github.com/MuntasirSZN/getquotes/compare/v0.2.2...v0.2.3) (2025-01-17)

### ✨ Features

- use actions better
  
  ### 🐞 Bug Fixes

- **ci:** script for pkg
  - **ci:** script for pkg
  
  
<a name="v0.2.2"></a>

## [v0.2.2](https://github.com/MuntasirSZN/getquotes/compare/v0.2.1...v0.2.2) (2025-01-17)

### 🐞 Bug Fixes

- pkgbuild ci
  - pkgbuild ci
  
  
<a name="v0.2.1"></a>

## [v0.2.1](https://github.com/MuntasirSZN/getquotes/compare/v0.2.0...v0.2.1) (2025-01-17)

### ✨ Features

- fresh start
  
  
<a name="v0.2.0"></a>

## [v0.2.0](https://github.com/MuntasirSZN/getquotes/compare/v0.1.2...v0.2.0) (2025-01-17)

### ✨ Features

- fresh start
  
  
<a name="v0.1.2"></a>

## [v0.1.2](https://github.com/MuntasirSZN/getquotes/compare/v0.1.1...v0.1.2) (2025-01-17)

### 🐞 Bug Fixes

- **workflow:** again
  - **workflow:** again
  
  
<a name="v0.1.1"></a>

## [v0.1.1](https://github.com/MuntasirSZN/getquotes/compare/v0.1.0...v0.1.1) (2025-01-17)

### Build

- **deps:** bump log from 0.4.22 to 0.4.25
  
  ### Chore

- **release:** 0.1.1
  - **workflow:** update to v3
  
  ### ✨ Features

- Add AUR
  
  ### 🐞 Bug Fixes

- my name in cargo.toml
  - sqlite
  - everything
  - everything
  - **logger:** Now works fix(cache): add default path and fix feat: --version param
  - **tests:** Final fix
  - **tests:** Checking
  - **tests:** trying
  - **workflow:** Now better feat: PKGBUILD
  - **workflow:** Now better feat: PKGBUILD
  
  
<a name="v0.1.0"></a>

## v0.1.0 (2025-01-15)

### ✨ Features

- ci
  - cargo.toml
  - Readme, and others
  - Massive Changes
  
  ### 🐞 Bug Fixes

- everything
  - everything
  - everything
  - everything
  - android
  - android
  - reqwest
  - License
  
  