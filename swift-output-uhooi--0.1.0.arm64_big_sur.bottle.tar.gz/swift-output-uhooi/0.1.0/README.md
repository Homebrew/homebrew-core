# swift-output-uhooi

[![CI](https://github.com/uhooi/swift-output-uhooi/actions/workflows/main.yml/badge.svg?branch=main)](https://github.com/uhooi/swift-output-uhooi/actions/workflows/main.yml)
[![Release](https://img.shields.io/github/v/release/uhooi/swift-output-uhooi)](https://github.com/uhooi/swift-output-uhooi/releases/latest)
[![License](https://img.shields.io/github/license/uhooi/swift-output-uhooi)](https://github.com/uhooi/swift-output-uhooi/blob/main/LICENSE)
[![Twitter](https://img.shields.io/twitter/follow/the_uhooi?style=social)](https://twitter.com/the_uhooi)

Uhooi speak the phrase.

## Table of Contents

- [Installation](#installation)
- [How to use](#how-to-use)
- [Contribution](#contribution)

## Installation

### Homebrew

TBD

### Mint

TBD

### Swift Package Manager

TBD

## How to use

TBD

## Contribution

I would be happy if you contribute :)

- [New issue](https://github.com/uhooi/swift-output-uhooi/issues/new)
- [New pull request](https://github.com/uhooi/swift-output-uhooi/compare)
