class SwiftOutputUhooi < Formula
  desc "Uhooi speak the phrase"
  homepage "https://github.com/uhooi/swift-output-uhooi"
  url "https://github.com/uhooi/swift-output-uhooi.git",
    tag: "0.1.0",
    revision: "c64a25feac6b4ae87e510a2f19eeaad457659ac9"
  license "MIT"
  head "https://github.com/uhooi/swift-output-uhooi.git", branch: "main"

  depends_on xcode: ["12.5.1", :build]

  def install
    system "swift", "build", "-c", "release", "--disable-sandbox"
    bin.install ".build/release/uhooi"
  end

  test do
    assert_match \
      "1: ┌|▼▼|┘<I'm uhooi." \
      "2: ┌|▼▼|┘<I'm uhooi.",
      shell_output("#{bin}/uhooi", "--include-counter", "-c", "2", "I'm uhooi.").chomp
    assert_match version.to_s, shell_output("#{bin}/uhooi --version").chomp
  end
end
